<!DOCTYPE html>
<html>
<head>
	<title>Demo</title>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="description" content="your nice">
	  <meta name="keywords" content="keyword, keyword2, keyword3">
	  <meta name="author" content="your name">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>	  
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light border-0 shadow-lg mb-5 py-3">
	  <a class="navbar-brand p-0 m-0" href="#"><img src="images/logo.png" width="90" height="50"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	    <div class="navbar-nav ml-auto">
	      <a class="nav-link active font-weight-bold" href="/">Home</a>
	      <a class="nav-link " href="about-us">About Us</a>
	      <a class="nav-link " href="privacy">Privacy</a>
	      <a class="nav-link " href="terms">Terms</a>
	    </div>
	  </div>
	</nav>
	
<div class="container">



	<!--Yo can write here-->
	<h1>Write Your hext here</h1>




</div>
<div class="container-fluid pt-3" style="background-color: #162447">
<div class="container">
<footer class="mt-4">
	<div class="row">
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Pages</p>



			<p><a href="/" class="text-decoration-none text-light">Home</a></p>
			<p><a href="about-us" class="text-decoration-none text-light">About Us</a></p>
			<p><a href="privacy" class="text-decoration-none text-light">Privacy Policy</a></p>
			<p><a href="terms" class="text-decoration-none text-light">Terms</a></p>
		</div>
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Social Links</p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-facebook"></i> Facebook</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-youtube"></i> Youtube</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-linkedin"></i> Linkedin</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-telegram"></i> Telegram</a></p>
		</div>
		<div class="col-md-4">
			<p class="text-white font-weight-bold">Developer Info</p>
			<p class="text-white">This Website completely develop by unlockdream.com</p>
		</div>
	</div>
</footer>
</div>
</div>


</body>
</html>