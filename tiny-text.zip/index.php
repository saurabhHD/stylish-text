<!DOCTYPE html>
<html>
<head>
	<title>Demo</title>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="description" content="your nice">
	  <meta name="keywords" content="keyword, keyword2, keyword3">
	  <meta name="author" content="your name">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>	  
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light border-0 shadow-lg mb-5 py-3">
	  <a class="navbar-brand p-0 m-0" href="#"><img src="images/logo.png" width="90" height="50"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	    <div class="navbar-nav ml-auto">
	      <a class="nav-link active font-weight-bold" href="/">Home</a>
	      <a class="nav-link " href="about-us">About Us</a>
	      <a class="nav-link " href="privacy">Privacy</a>
	      <a class="nav-link " href="terms">Terms</a>
	    </div>
	  </div>
	</nav>
	<div class="container-fluid mb-3">
	<div class="row">
		<div class="col-md-1 "></div>
		<div class="col-md-6  px-4 pt-5">
			<div class="input-group mb-1" style="box-shadow: none;">
			 <textarea type="text" class="form-control fancytext" required="required" name="text" placeholder="Enter Your text here" value=""></textarea>
			</div>	
			<div class="row ml-2 mb-3">
				<div class="col-2"><span class="text-secondry">Share on</span></div>
				<div class="col-1"><a href="whatsapp://send?text=http://www.example.com"><i class="fa fa-whatsapp fa-lg text-success share-icons"></i></a></div>
				<div class="col-1"><a href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fparse.com"><i class="fa fa-facebook fa-lg text-primary share-icons"></i></a></div>
				<div class="col-1"><a href="mailto:?subject=Fancy%20Text%20Generator%20%E1%90%88%20%231%20%F0%9D%95%AE%F0%9D%96%94%F0%9D%96%94%F0%9D%96%91%20%26%20Stylish%20Text%20Fonts%20%E2%9C%85&amp;body=https%3A%2F%2Fwww.example.com%2F"><i class="fa fa-envelope-open fa-lg text-danger share-icons"></i></a></div>
				<div class="col-1"><a href="https://twitter.com/intent/tweet/?text=example.com"><i class="fa fa-twitter fa-lg text-info share-icons"></i></a></div>
				<div class="col-1"><a href="http://instagram.com/###?ref=badge"><i class="fa fa-instagram fa-lg text-danger share-icons"></i></a></div>
			</div>
			<div id="result">
			
<div class="input-group mb-3 ok"><input type="text" class="form-control text-9" value="ᴘʀᴇᴠɪᴇᴡ ᴛᴇxᴛ" id="copy_8" readonly="readonly"><div class="input-group-append"><span class="input-group-text copybutton"  data-clipboard-action="copy" data-clipboard-target="#copy_8"><i class="fa fa-copy text-secondary fa-2x"></i></span></div></div>



<div class="input-group mb-3 ok"><input type="text" class="form-control text-17" value="ₚᵣₑᵥᵢₑ ₜₑₓₜ" id="copy_16" readonly="readonly"><div class="input-group-append"><span class="input-group-text copybutton"  data-clipboard-action="copy" data-clipboard-target="#copy_16"><i class="fa fa-copy text-secondary fa-2x"></i></span></div></div>

<div class="input-group mb-3 ok"><input type="text" class="form-control text-18" value="ᴾʳᵉᵛⁱᵉʷ ᵀᵉˣᵗ" id="copy_17" readonly="readonly"><div class="input-group-append"><span class="input-group-text copybutton"  data-clipboard-action="copy" data-clipboard-target="#copy_17"><i class="fa fa-copy text-secondary fa-2x"></i></span></div></div>

<div class="input-group mb-3 ok"><input type="text" class="form-control text-19" value="Ⓟⓡⓔⓥⓘⓔⓦ Ⓣⓔⓧⓣ" id="copy_18" readonly="readonly"><div class="input-group-append"><span class="input-group-text copybutton"  data-clipboard-action="copy" data-clipboard-target="#copy_18"><i class="fa fa-copy text-secondary fa-2x"></i></span></div></div>


</div>
<center>

</center>
</div>
		<div class="col-md-1 "></div>
		<div class="col-md-4 d-lg-block d-none">
			<div class="container shadow-lg">
			<div class="row shadow-sm py-3">
					
					<div class="col-1"><i class="fa fa-arrow-left text-primary"></i></div>
					<div class="col-3 "><span class="font-weight-bold">Demo Text</span></div>
					<div class="col-8"></div>
					
				</div>
				<div class="row">
					<div class="col-12" style="background-color: #E6ECF4;height: 130px;"></div>
				</div>
				<div class="row">
					
					<div class="col-4 position-relative">
						<div  class="bg-primary" style="border-radius: 50%;width: 100px;height: 100px;position: absolute; top:-50px;z-index: 1;"></div>
					</div>
					<div class="col-8"></div>
				</div>
				<div class="row" style="margin-top: 65px;">
					<div class="col-4">
						<h4 class="font-weight-bold m-0 p-0">Demo</h4>
						<p class="text-secondary">@demo</p>
					</div>
					<div class="col-8"></div>
				</div>
				<div class="row">
					<div class="col-12 p-3"><p class="text-secondary prview-text">This the genrated text</p></div>
					<div class="col-12"><i class="fa fa-map-marker text-secondary" style="font-size: 25px;"></i>&nbsp;&nbsp;<span class="text-secondary">India</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="" class="text-decoration-none"><i class="fa fa-link text-secondary"></i>&nbsp;&nbsp;unlockdream.com</a></div>
				</div>
				<div class="row">
					<div class="col-12">
						<hr>
					</div>
				</div>
			
			</div>
		</div>
	</div>
</div>
<button class="btn preview-btn d-block d-lg-none" style="position: fixed;bottom: 10px;right: 20px;background-color: #2A81FB;z-index: 1000;color: #fff">Preview</button>
<div class="container">



	<!--Yo can write here-->
	<h1 class="text-secondary mt-4">How to Use Our Tiny Text Generator?</h1>

	<p class="text-secondary">Enter text above under the “Input” text field.
	Select the style you want. You can read more about the types in the “What is Tiny Tiny Text” section below.
	Copy the converted text from the “Output” field.
	</p>
	<h2 class="text-secondary">What is tiny text?</h2>
	<p class="text-secondary">You can use this generator to convert normal text into tiny letters to place into Facebook posts, Twitter tweets, Instagram updates, Discord chats, and other social media posts and status updates.
Typing the text “little” in the Tiny text generator using the Tiny caps option will result in a Tinyer font size, rather than the regular font size which would lead to the title to appear as “LITTLE TEXT”. 
It is not unusual for the Tiny caps text to be used by a number of individuals, businesses, etc for texts that could be difficult to read in their normal form.
Several of these texts include acronyms which are longer than three to four letters. In addition, in plays and stage directions, the Tiny letters feature can be used to indicate the name of characters before their lines or dialogue appears.
The Tiny caps letterform is sometimes used in languages that use names by separating them by the surname of a person. Tiny caps contains all the letters the alphabet, which means that no letters are missing or not visible.
There are over 100,000 symbols that are specified in the Unicode standard, which can be decoded as letters, numbers, and pictures, just like the symbols that you're seeing on this screen now.
</p>
<h2 class="text-secondary">How does tiny text work?</h2>
<p class="text-secondary">Tiny text known as subscript words is also at the core of the tiny aesthetic text maker.
These symbols are used very often in math notations, so Unicode thought it would be good to have an official text symbol for these characters. However, unlike a normal text converter, the tiny text converter does not necessarily have an alphabet that is included in Unicode.
Type whatever you want into the text box below, and we’ll convert the letters and (some) numbers into your selected font (it’s the default). 
Choose a font style for writing with the radio buttons. You can choose from three font styles: s s, susript and superscript. The font for tiny caps is usually the same size as many this font for non-capital letters, in other words .
In general, these fonts work well for commenting on message boards or unique handle names. Because these fonts use Unicode characters, you can paste them on other applications where they will remain the same size. (Just be careful - sometimes the websites or app don't support all unicode characters!)
Those are some of the alphabets that will hopefully work for you if you're looking for a tiny letter generator.
Using our text to caps tool is very easy. All you have to do is copy and paste your text that you want to convert. You can also type by yourself and you can check results in real-time. 
We have not added any option to upload .doc, .docx or .txt file. Because we don't think that is there any Possibility when the user wants to convert the whole file to subscript, superscript or tiny capitals. But if you think there is any need for this option you are welcome to contact us.
</p>

<h2 class="text-secondary">More about tiny Caps Converter:</h2>
<p class="text-secondary mb-4">Today, tiny caps text generator is mostly used online when users want to post something on Tumblr, Facebook, and other social networks. You can use the tiny caps text generator to make text tinyer. It can be used in the opening of a sentence to catch the attention of the readers.</p>
</div>
<div class="container-fluid pt-3 shadow-lg" style="background-color: #162447;z-index: 2">
<div class="container">
<footer class="mt-4">
	<div class="row">
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Pages</p>



			<p><a href="/" class="text-decoration-none text-light">Home</a></p>
			<p><a href="about-us" class="text-decoration-none text-light">About Us</a></p>
			<p><a href="privacy" class="text-decoration-none text-light">Privacy Policy</a></p>
			<p><a href="terms" class="text-decoration-none text-light">Terms</a></p>
		</div>
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Social Links</p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-facebook"></i> Facebook</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-youtube"></i> Youtube</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-linkedin"></i> Linkedin</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-telegram"></i> Telegram</a></p>
		</div>
		<div class="col-md-4">
			<p class="text-white font-weight-bold">Developer Info</p>
			<p class="text-white">This Website completely develop by unlockdream.com</p>
		</div>
	</div>
</footer>
</div>
</div>
<div class="modal mt-3" id="sk">
		<div class="modal-body bg-light">
			<div class="row shadow-sm py-3">
					
					<div class="col-3"><i class="fa fa-arrow-left text-primary fa-2x"  data-dismiss="modal"></i></div>
					<div class="col-6 "><span class="font-weight-bold">Demo Text</span></div>
					<div class="col-3"></div>
					
				</div>
				<div class="row">
					<div class="col-12" style="background-color: #E6ECF4;height: 130px;"></div>
				</div>
				<div class="row">
					
					<div class="col-4 position-relative">
						<div  class="bg-primary" style="border-radius: 50%;width: 100px;height: 100px;position: absolute; top:-50px;z-index: 1;"></div>
					</div>
					<div class="col-8"></div>
				</div>
				<div class="row" style="margin-top: 65px;">
					<div class="col-4">
						<h4 class="font-weight-bold m-0 p-0">Demo</h4>
						<p class="text-secondary">@demo</p>
					</div>
					<div class="col-8"></div>
				</div>
				<div class="row">
					<div class="col-12 p-3"><p class="text-secondary prview-text">This the genrated text</p></div>
					<div class="col-12"><i class="fa fa-map-marker text-secondary" style="font-size: 25px;"></i>&nbsp;&nbsp;<span class="text-secondary">India</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="" class="text-decoration-none"><i class="fa fa-link text-secondary"></i>&nbsp;&nbsp;unlockdream.com</a></div>
				</div>
				<div class="row">
					<div class="col-12">
						<hr>
					</div>
				</div>
		</div>
	
</div>
<script src="srcipt/cp.js"></script>
<script src="srcipt/main.js"></script>
<script src="srcipt/test.js"></script>
<script>
	$(document).ready(function(){
		$(".preview-btn").click(function(){
			$('#sk').modal('show');
		});
		$(".ok").each(function(){
			$(this).click(function(){
				var text = this.children[0].value;
				$(".prview-text").html(text);
				$(".preview-btn").click(function()
				{
				$('#sk').modal('show');
				
				});
			});
		});
	});
</script>
</body>
</html>