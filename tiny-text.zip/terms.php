<!DOCTYPE html>
<html>
<head>
	<title>Demo</title>
	<meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <meta name="description" content="your nice">
	  <meta name="keywords" content="keyword, keyword2, keyword3">
	  <meta name="author" content="your name">
	  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
	  <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
		<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.bundle.min.js" integrity="sha384-LtrjvnR4Twt/qOuYxE721u19sVFLVSA4hf/rRt6PrZTmiPltdZcI7q7PXQBYTKyf" crossorigin="anonymous"></script>	  
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-light border-0 shadow-lg mb-5 py-3">
	  <a class="navbar-brand p-0 m-0" href="#"><img src="images/logo.png" width="90" height="50"></a>
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
	    <div class="navbar-nav ml-auto">
	      <a class="nav-link active font-weight-bold" href="/">Home</a>
	      <a class="nav-link " href="about-us">About Us</a>
	      <a class="nav-link " href="privacy">Privacy</a>
	      <a class="nav-link " href="terms">Terms</a>
	    </div>
	  </div>
	</nav>
	
<div class="container">



	<!--Yo can write here-->
	<h1 class="text-secondary">Terms and Conditions ("Terms")</h1>
	<p class="text-secondary mb-3">
Last updated: September 28, 2020
<br><br>
Please read these Terms and Conditions ("Terms", "Terms and Conditions") carefully before using the (Domain name)/ website (the "Service") operated by thefancytext.com ("us", "we", or "our").
<br><br>
Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users and others who access or use the Service.
<br><br>
By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service. The Terms and Conditions agreement for thefancytext.com.
<br><br>
Links To Other Web Sites
Our Service may contain links to third-party web sites or services that are not owned or controlled by thefancytext.com.
<br><br>
thefancytext.com has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third party web sites or services. You further acknowledge and agree that thefancytext.com shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services.
<br><br>
We strongly advise you to read the terms and conditions and privacy policies of any third-party web sites or services that you visit.
<br><br>
Governing Law
These Terms shall be governed and construed in accordance with the laws of Maharashtra, India, without regard to its conflict of law provisions.
<br><br>
Our failure to enforce any right or provision of these Terms will not be considered a waiver of those rights. If any provision of these Terms is held to be invalid or unenforceable by a court, the remaining provisions of these Terms will remain in effect. These Terms constitute the entire agreement between us regarding our Service, and supersede and replace any prior agreements we might have between us regarding the Service.
<br><br>
Changes
We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
<br><br>
By continuing to access or use our Service after those revisions become effective, you agree to be bound by the revised terms. If you do not agree to the new terms, please stop using the Service.
<br><br>
Contact Us
If you have any questions about these Terms, please contact us.</p>




</div>
<div class="container-fluid pt-3" style="background-color: #162447">
<div class="container">
<footer class="mt-4">
	<div class="row">
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Pages</p>



			<p><a href="/" class="text-decoration-none text-light">Home</a></p>
			<p><a href="about-us" class="text-decoration-none text-light">About Us</a></p>
			<p><a href="privacy" class="text-decoration-none text-light">Privacy Policy</a></p>
			<p><a href="terms" class="text-decoration-none text-light">Terms</a></p>
		</div>
		<div class="col-md-4 mb-3">
			<p class="text-white font-weight-bold">Social Links</p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-facebook"></i> Facebook</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-youtube"></i> Youtube</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-linkedin"></i> Linkedin</a></p>
			<p><a href="#" class="text-decoration-none text-light"><i class="fa fa-telegram"></i> Telegram</a></p>
		</div>
		<div class="col-md-4">
			<p class="text-white font-weight-bold">Developer Info</p>
			<p class="text-white">This Website completely develop by unlockdream.com</p>
		</div>
	</div>
</footer>
</div>
</div>


</body>
</html>